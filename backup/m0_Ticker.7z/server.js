// server.js — unified HTTP server for BRB + Ticker
// Save at: B:\m0_scripts\m0_PopUps\server.js
// Run:     npm i express cors && node server.js

const path = require('path');
const express = require('express');
const cors = require('cors');

const HTTP_HOST = '127.0.0.1';
const HTTP_PORT = 3000;

// Adjust this if you move the folder
const TICKER_DIR = 'B:\\m0_scripts\\m0_Ticker';
const PUBLIC_TICKER = path.resolve(TICKER_DIR);

const app = express();
app.use(cors());
app.use(express.json({ limit: '256kb' }));

// ---- In-memory state (persist to a file later if you want)
const state = {
  ticker: {
    isActive: false,
    messages: [],
    displayDuration: 5,
    intervalBetween: 10,
    _updatedAt: Date.now()
  },
  brb: {
    isActive: false,
    text: 'Be Right Back',
    _updatedAt: Date.now()
  }
};

// ---- Health
app.get('/health', (req, res) => {
  res.json({ ok: true, t: Date.now() });
});

// ---- Ticker API
app.get('/ticker/state', (req, res) => {
  res.json(state.ticker);
});

app.post('/ticker/state', (req, res) => {
  try {
    const { isActive, messages, displayDuration, intervalBetween } = req.body || {};
    if (Array.isArray(messages)) state.ticker.messages = messages.map(String);
    if (typeof isActive === 'boolean') state.ticker.isActive = isActive;
    if (Number.isFinite(displayDuration)) state.ticker.displayDuration = Math.max(2, Math.min(90, displayDuration | 0));
    if (Number.isFinite(intervalBetween)) state.ticker.intervalBetween = Math.max(0, Math.min(300, intervalBetween | 0));
    state.ticker._updatedAt = Date.now();
    res.json({ ok: true, state: state.ticker });
  } catch (e) {
    res.status(400).json({ ok: false, error: e.message });
  }
});

// ---- BRB API
app.get('/brb/state', (req, res) => {
  res.json(state.brb);
});

app.post('/brb/state', (req, res) => {
  try {
    const { isActive, text } = req.body || {};
    if (typeof isActive === 'boolean') state.brb.isActive = isActive;
    if (typeof text === 'string') state.brb.text = text;
    state.brb._updatedAt = Date.now();
    res.json({ ok: true, state: state.brb });
  } catch (e) {
    res.status(400).json({ ok: false, error: e.message });
  }
});

// ---- Static files: /ticker/index.html and /ticker/output.html
app.use('/ticker', express.static(PUBLIC_TICKER, {
  etag: false,
  lastModified: false,
  cacheControl: false,
  maxAge: 0
}));

// ---- Start HTTP
app.listen(HTTP_PORT, HTTP_HOST, () => {
  console.log(`[http] listening on http://${HTTP_HOST}:${HTTP_PORT}`);
  console.log(`[http] ticker files at http://${HTTP_HOST}:${HTTP_PORT}/ticker/`);
});
